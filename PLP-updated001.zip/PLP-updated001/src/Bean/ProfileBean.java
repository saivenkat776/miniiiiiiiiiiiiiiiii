package Bean;

public class ProfileBean {
	private String user;
	private String pass;
	private String role;
	public String getUser() {
		return user;
	}
	public String getPass() {
		return pass;
	}
	public String getRole() {
		return role;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	
}
