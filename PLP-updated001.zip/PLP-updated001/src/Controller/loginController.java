package Controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import Dao.DB;

public class loginController extends HttpServlet{


		
	public  void doGet(HttpServletRequest request,HttpServletResponse response) 
			   throws ServletException,IOException
			{
		Connection con = null;
		RequestDispatcher rd = null;
		ResultSet resultSet = null;
		Statement statement = null;
		String sql;
		String role ="";
		int i=0;
		String user=request.getParameter("username");
		String pass=request.getParameter("Password");
		
		try {
			con=DB.getConnection(); 
			statement=con.createStatement();
			System.out.println("connected");
			sql="select role_code from user_role where user_name='"+user+"' and password='"+pass+"'";
			i=statement.executeUpdate(sql);
			resultSet = statement.executeQuery(sql);
			while(resultSet.next()){
				role=resultSet.getString(1);
				System.out.println(role);
			}
			System.out.println(i);
			if (i==1 && role.equals("admin"))
			{
			rd=request.getRequestDispatcher("/admin.jsp");
			}
			if (i==1 && role.equals("agent"))
			{
			rd=request.getRequestDispatcher("/agent.jsp");
			}
			if (i==1 && role.equals("insured"))
			{
			rd=request.getRequestDispatcher("/insured.jsp");
			}
			if(i==0)
			{
				rd=request.getRequestDispatcher("/login_denied.jsp");
			}
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		rd.forward(request, response);
		
}
}
