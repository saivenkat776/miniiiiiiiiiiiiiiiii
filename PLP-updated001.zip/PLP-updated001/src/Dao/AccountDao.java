package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import Bean.AccountBean;

public class AccountDao {

	public long addAccount(AccountBean accbean) {
		Connection con = null;
		ResultSet resultSet = null;
		  PreparedStatement pstmt = null;
		  long  Accseq=0;
		  try {
			  
			  con=DB.getConnection(); 
			  
			  String ins_str ="insert into accounts values(Acc_seq.NEXTVAL,?,?,?,?,?,?,?)";
			  
			  pstmt = con.prepareStatement(ins_str);
			  
			  pstmt.setString(1,accbean.getName());
			  pstmt.setString(2,accbean.getStreet());
			  pstmt.setString(3,accbean.getCity());
			  pstmt.setString(4,accbean.getState());
			  pstmt.setInt(5,accbean.getZip());
			  pstmt.setString(6,accbean.getBusiness());
			  pstmt.setString(7,accbean.getUname());
			  
			  
			  int updateCount = pstmt.executeUpdate();
			  pstmt = con.prepareStatement("SELECT Acc_seq.CURRVAL FROM DUAL");
				resultSet=pstmt.executeQuery();
			  
			  if(updateCount==1) {
			  if(resultSet.next())
				{
				  String acc=resultSet.getString(1);
				 Accseq=Long.parseLong(acc);
				 return Accseq;
							
				}
			  }
		
				
		  }catch(Exception ex)
		  {
			  System.out.println(ex.toString());
			  return Accseq;
		  }
		return Accseq;
	}

}
