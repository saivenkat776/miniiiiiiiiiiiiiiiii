package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class InsertPolicyDao {
	Connection con=null;
	ResultSet resultSet = null;
	PreparedStatement pstmt = null;
	 int k=0;
	public int Inspol(int policynumber, HashMap<String, String> ans,String pol_id) {
		for(Map.Entry<String,String> m:ans.entrySet())
		{
			if(m.getValue() !=null) {
		try {
			con=DB.getConnection();
			String val=m.getValue();
			System.out.println(policynumber+" "+pol_id+" "+m.getValue());
			String ins_str ="insert into  policy_details values("+policynumber+",'"+pol_id+"','"+val+"')";
			pstmt = con.prepareStatement(ins_str);
			   k=pstmt.executeUpdate();
			 
		
	}catch (Exception e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
			}
		}
		  return k;

}
}
