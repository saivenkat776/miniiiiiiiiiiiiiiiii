package Service;

import java.util.HashMap;

import Dao.InsertPolicyDao;
import Dao.PolicyInsertDao;
import Dao.PremiumCalDao;

public class PremiumCalService {

	public int CalculatePremium(HashMap<String, String> ans,long acc) {
		// TODO Auto-generated method stub
		PremiumCalDao predao=new PremiumCalDao();
		int res=predao.CalDao(ans); 
		
	PolicyInsertDao polins=new PolicyInsertDao();
	 
		int res1=polins.PolIns(res,acc);
		return res1;
		
	}

	public int Inspol(int policynumber, HashMap<String, String> ans,String pol_id) {
		// TODO Auto-generated method stub
		InsertPolicyDao insdao=new InsertPolicyDao();
		int k=insdao.Inspol(policynumber,ans,pol_id);
		return k;
	}


}
